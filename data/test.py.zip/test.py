import numpy as np
import pandas as pd
x = [1,2,3]
